<template>
<footer class="w3-container w3-blue-grey w3-bottom">
<slot></slot>
</footer>
</template>
<script>
export default {
  name: 'secFooter'
}
</script>
<style scoped>

</style>
