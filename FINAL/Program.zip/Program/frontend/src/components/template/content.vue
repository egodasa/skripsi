<template>
<!-- Top container -->
<div class="w3-main" style="margin-left:250px;margin-top:43px;">
<slot></slot>
</div>
</template>
<script>
export default {
  name: 'secContent'
}
</script>

<style scoped>

</style>
