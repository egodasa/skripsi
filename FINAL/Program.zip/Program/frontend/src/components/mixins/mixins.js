export const dosenConf = {
    data () {
        return {
            dosenMenu : [
            {
              path : '/',
              name : 'Beranda',
              icon : 'fa-eye fa-fw'
              },
            {
              path : '/dosen/ujian',
              name : 'Daftar Ujian',
              icon : 'fa-eye fa-fw'
            }],
            userMenu :[
            {
              path : '/',
              name : 'Beranda',
              icon : 'fa-eye fa-fw'
              }]
        }
    }
}
